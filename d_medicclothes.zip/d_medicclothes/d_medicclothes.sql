INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
	('medicclothes', 'Medic Clothes', '20', '0', '1')
;