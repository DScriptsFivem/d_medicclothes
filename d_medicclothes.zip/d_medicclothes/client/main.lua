ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('d_medicclothes:Use1')
AddEventHandler('d_medicclothes:Use1', function()
	local lib, anim = 'anim@heists@narcotics@funding@gang_idle', 'gang_chatting_idle01'
	local playerPed = PlayerPedId()

	ESX.Streaming.RequestAnimDict(lib, function()
		TaskPlayAnim(playerPed, lib, anim, 8.0, -8.0, 6000, 0, 0, false, false, false)
		SetPedComponentVariation(GetPlayerPed(-1), 11, Config.torso, Config.torso2, 0)
		SetPedComponentVariation(GetPlayerPed(-1), 4, Config.pants, Config.pants2, 0)
		SetPedComponentVariation(GetPlayerPed(-1), 6, Config.sneaker, Config.sneaker2, 0)
		SetPedComponentVariation(GetPlayerPed(-1), 8, Config.tshirt, Config.tshirt2, 0)
		SetPedComponentVariation(GetPlayerPed(-1), 3, Config.arms, Config.arms2, 0)		
        if Config.notifications == true then
            exports['d_notify']:sendNotify( Config.Title, Config.Message, 5000, 'success')
        end
	end)
end)





