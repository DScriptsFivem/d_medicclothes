Config = {}

Config.notifications = true

Config.Title = "MedicClothes" -- Message Title

Config.Message = "Successfully used" -- Message

Config.torso = 13  
Config.torso2 = 3 

Config.pants = 24  
Config.pants2 = 5  

Config.sneaker = 1
Config.sneaker2 = 1

Config.tshirt = 15
Config.tshirt2 = 0

Config.arms = 92
Config.arms2 = 0